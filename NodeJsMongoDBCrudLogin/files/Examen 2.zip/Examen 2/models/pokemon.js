const mongoose = require('mongoose');
const bcrypt = require('bcrypt-nodejs');
const Schema = mongoose.Schema;

const pokemonSchema = new Schema({
  nombre: { type: String, required: true, unique: true},
  tipo: { type: String, required: true}
});


pokemonSchema.methods.findAll= async () => {
  const Pokemon = mongoose.model("pokemon", pokemonSchema);
  return  await Pokemon.find()
};

pokemonSchema.methods.findById = async function (id) {
  const Pokemon = mongoose.model("pokemon", pokemonSchema);
  return await Pokemon.findById(id);
};

//Insertar pokemon
pokemonSchema.methods.insert= async function () {
  //await this.save();
  await this.save()
  .then(res => {
    console.log("saved: " + res);
  })  .catch(err => {
    console.log(err)  });
};

module.exports = mongoose.model('pokemon', pokemonSchema);


