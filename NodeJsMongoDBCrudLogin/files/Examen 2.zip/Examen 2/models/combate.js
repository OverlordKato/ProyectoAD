const mongoose = require('mongoose');
const bcrypt = require('bcrypt-nodejs');
const Schema = mongoose.Schema;

const combateSchema = new Schema({
  pokemon1: { type: String, required: true},
  pokemon2: { type: String, required: true},
  resultado: { type: String, required: true},
});


combateSchema.methods.findAll= async () => {
  const Combate = mongoose.model("combate", combateSchema);
  return  await Combate.find()
};

combateSchema.methods.findById = async function (id) {
  const Combate = mongoose.model("combate", combateSchema);
  return await Combate.findById(id);
};

//Insertar pokemon
combateSchema.methods.insert= async function () {
  //await this.save();
  await this.save()
  .then(res => {
    console.log("saved: " + res);
  })  .catch(err => {
    console.log(err)  });
};

module.exports = mongoose.model('combate', combateSchema);


