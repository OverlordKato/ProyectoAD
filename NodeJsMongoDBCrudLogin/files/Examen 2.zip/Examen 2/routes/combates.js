const router = require('express').Router();
const Combate = require('../models/combate');
const Pokemon = require('../models/pokemon');
const { default: mongoose } = require('mongoose');

router.get('/combate', async(req, res, next) => {
    const combate = new Combate;
    const combates = await combate.findAll();
    const pokemon = new Pokemon;
    const pokemons = await pokemon.findAll();

    res.render('combate', {
        combates: combates, pokemons: pokemons
    });
    
  });

router.post('/combate', async (req, res, next) => {
  try{
    if(req.body.pokemons.length == 2) {
      const pokemon = new Pokemon();
      var resultado = "";

      const pokemon1 = await pokemon.findById(req.body.pokemons[0]);
      const pokemon2 = await pokemon.findById(req.body.pokemons[1]);

      if(pokemon1.nombre == "Mewtwo" || pokemon1.nombre == "Mew" || pokemon2.nombre == "Mew" || pokemon2.nombre == "Mewtwo"){
        if((pokemon1.nombre == "Mewtwo" || pokemon1.nombre == "Mew") && (pokemon2.nombre == "Mew" || pokemon2.nombre == "Mewtwo")){
          resultado = "Empate";
        }else if(pokemon1.nombre == "Mewtwo" || pokemon1.nombre == "Mew"){
          resultado = "Gano pokemon 1";
        }else{
          resultado = "Gano pokemon 2";
        }
      }else{
        if(pokemon1.tipo == "planta" && pokemon2.tipo == "agua"){
          resultado = "Gano pokemon 1";
        }else if(pokemon1.tipo == "agua" && pokemon2.tipo == "planta"){
          resultado = "Gano pokemon 2";
        }else if(pokemon1.tipo == "fuego" && pokemon2.tipo == "planta"){
          resultado = "Gano pokemon 1";
        }else if(pokemon1.tipo == "planta" && pokemon2.tipo == "fuego"){
          resultado = "Gano pokemon 2";
        }else if(pokemon1.tipo == "fuego" && pokemon2.tipo == "agua"){
          resultado = "Gano pokemon 2";
        }else if(pokemon1.tipo == "agua" && pokemon2.tipo == "fuego"){
          resultado = "Gano pokemon 1";
        } else if(pokemon1.tipo == "psiquico" && (pokemon2.tipo == "agua" || pokemon2.tipo == "fuego")){
          resultado = "Gano pokemon 1";
        }else if(pokemon1.tipo == "fantasma" && pokemon2.tipo == "psiquico"){
          resultado = "Gano pokemon 1";
        }else if(pokemon1.tipo == "psiquico" && pokemon2.tipo == "fantasma"){
          resultado = "Gano pokemon 2";
        }else{
          var randomNumber = Math.floor(Math.random() * 2) + 1;
          if(randomNumber == 1){
            resultado = "Gano pokemon 1";
          }else{
            resultado = "Gano pokemon 2";
          }
        }
      }

      const combate = new Combate();
      combate.pokemon1 = pokemon1._id;
      combate.pokemon2 = pokemon2._id;
      combate.resultado = resultado;
      await combate.insert();
      res.redirect('/combate');
    }else{
      // Manejo de errores
      console.error("Error al combatir numero:");
      res.status(500).send("Error al combatir numero");
    }
  }catch (error) {
    // Manejo de errores
    console.error("Error al combatir:", error);
    res.status(500).send("Error al combatir");
  }
});

module.exports = router;