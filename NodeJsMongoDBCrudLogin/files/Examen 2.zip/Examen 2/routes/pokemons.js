const router = require('express').Router();
const Pokemon = require('../models/pokemon');
const { default: mongoose } = require('mongoose');

router.get('/', async(req, res, next) => {
    res.redirect('/pokemon');
});

router.get('/pokemon', async(req, res, next) => {
    const pokemon = new Pokemon;
    const pokemons = await pokemon.findAll();
    res.render('pokemon', {
        pokemons: pokemons
    });
});

// Añadir asignatura añadiendosela a los usuarios seleccionados
router.post('/pokemon/addPokemon', async (req, res, next) => {
    try{
        const pokemon = new Pokemon(req.body);
        await pokemon.insert();
        res.redirect('/pokemon');
    }catch (error) {
        // Manejo de errores
        console.error("Error al insertar:", error);
        res.status(500).send("Error al insertar");
    }
  });

module.exports = router;